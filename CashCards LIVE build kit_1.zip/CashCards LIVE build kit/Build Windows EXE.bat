@echo off
setlocal EnableExtensions
title Build CashCards LIVE.exe
cd /d "%~dp0"
echo.
echo  === Building CashCards LIVE.exe ===
echo.

rem ---- find the app source in this folder ----
set "SRC="
if exist "CashCards LIVE Dashboard.pyw" set "SRC=%~dp0CashCards LIVE Dashboard.pyw"
if not defined SRC for /f "delims=" %%F in ('dir /b /o-d "*LIVE Dashboard*.pyw" 2^>nul') do if not defined SRC set "SRC=%~dp0%%F"
if not defined SRC for /f "delims=" %%F in ('dir /b /o-d "*LIVE Dashboard*.py" 2^>nul') do if not defined SRC set "SRC=%~dp0%%F"
if not defined SRC (
  echo  Could not find "CashCards LIVE Dashboard.pyw" in this folder.
  echo  Put this build file in the same folder as the app and run it again.
  goto :end
)
echo  Source: %SRC%

rem ---- find Python ----
set "PYEXE="
if exist "%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe" set "PYEXE=%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
if not defined PYEXE for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%P"
if not defined PYEXE for /f "delims=" %%P in ('python -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%P"
if not defined PYEXE (
  echo  Python was not found. Install it from https://www.python.org/downloads/ and run this again.
  goto :end
)
echo  Python: %PYEXE%
echo.

rem ---- build ----
"%PYEXE%" -m pip --version >nul 2>nul || "%PYEXE%" -m ensurepip --upgrade
"%PYEXE%" -m pip install --upgrade --quiet pyinstaller truststore certifi
if errorlevel 1 ( echo  Could not install PyInstaller. & goto :end )

"%PYEXE%" -m PyInstaller --onefile --windowed --noconfirm --clean ^
  --name "CashCards LIVE" --hidden-import truststore --hidden-import certifi ^
  --distpath "%~dp0." --workpath "%TEMP%\ccl_build" --specpath "%TEMP%\ccl_build" ^
  "%SRC%"
if errorlevel 1 ( echo. & echo  Build FAILED - see the messages above. & goto :end )

echo.
echo  ==========================================================
echo   Done:  %~dp0CashCards LIVE.exe
echo.
echo   Send people:  CashCards LIVE.exe  +  your .env file
echo   (no Python or code needed on their computer)
echo  ==========================================================
explorer /select,"%~dp0CashCards LIVE.exe"

:end
echo.
pause
